export default async function Featured() {
  // Placeholder for Featured Layout 1
  return (
    <section className="mb-6 border p-4 rounded">
      <h2 className="font-semibold mb-2">Featured Stories</h2>
      <p>Add featured layout cards here</p>
    </section>
  );
}
